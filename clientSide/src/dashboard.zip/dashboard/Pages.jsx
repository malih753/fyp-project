import React from 'react'
import './pages.css';
import LabHeader from './../account/profile/ProfileHeader.jsx';

const Pages = () => {
  return (
    <div>
    <LabHeader />
           <div className='pages-main'>
           <h2>Pages</h2>
           <p>
             Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorum placeat similique minus, 
             debitis possimus fugit eveniet nam cupiditate esse consequatur ut minima architecto earum ea 
             culpa 
             impedit quo nobis ipsa adipisci sint commodi quae expedita facere. Impedit id soluta officiis.
           </p>
           <p>
            Lorem, ipsum dolor sit amet consectetur adipisicing elit.
             Doloremque harum tenetur impedit voluptates suscipit earum delectus, 
             quia ipsa autem eos voluptate enim quo pariatur excepturi? Iure,
              temporibus cumque error voluptate iste voluptatum ad a labore et 
              voluptates quidem pariatur iusto enim tempora debitis 
            id quos nihil necessitatibus ipsa quo laudantium?
           </p>
           </div>
 </div>
 
  )
}

export default Pages
