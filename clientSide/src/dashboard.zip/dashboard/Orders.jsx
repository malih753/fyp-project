import React from 'react'
import './orders.css';
import LabHeader from '../account/profile/LabHeader';

const Orders = () => {
  return (
    <div>
    <LabHeader/>
           <div className='orders-main'>
           <h2>Offered Test</h2>
           <p>
             Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorum placeat similique minus, 
             debitis possimus fugit eveniet nam cupiditate esse consequatur ut minima architecto earum ea 
             culpa 
             impedit quo nobis ipsa adipisci sint commodi quae expedita facere. Impedit id soluta officiis.
           </p>
           <p>
            Lorem, ipsum dolor sit amet consectetur adipisicing elit.
             Doloremque harum tenetur impedit voluptates suscipit earum delectus, 
             quia ipsa autem eos voluptate enim quo pariatur excepturi? Iure,
              temporibus cumque error voluptate iste voluptatum ad a labore et 
              voluptates quidem pariatur iusto enim tempora debitis 
            id quos nihil necessitatibus ipsa quo laudantium?
           </p>
           </div>
 </div>
 
  )
}

export default Orders


/*
import React from 'react'
import './offeredTest.css';
import LabHeader from '../account/profile/LabHeader';
import Sidebar from './Sidebar';

const OfferedTest = () => {
  return (
    <div>
       <LabHeader/>
              <div className='offeredtest-main'>
               
              <h2>Offered Test</h2>
              </div>
    </div>
    
  )
}

export default OfferedTest

*/
 