import React, { useState } from 'react';
import { MDBBtn, MDBModal, MDBModalBody, MDBModalContent, MDBModalDialog, MDBModalFooter, MDBModalHeader, MDBModalTitle } from 'mdb-react-ui-kit';

const CustomTestForm = ({ isOpen, toggleOff, onSave }) => {
  const [testType, setTestType] = useState('');
  const [testName, setTestName] = useState('');
  const [testId, setTestId] = useState('');
  const [testDescription, setTestDescription] = useState('');
  const [testAlias, setTestAlias] = useState('');
  const [testInstructions, setTestInstructions] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [testRequirement, setTestRequirement] = useState('');
  const [startingPrice, setStartingPrice] = useState('');
  const [reportsDuration, setReportsDuration] = useState('');

  const handleSaveChanges = () => {
    const newTest = {
      testType,
      testName,
      testId,
      testDescription,
      testAlias,
      testInstructions,
      shortDescription,
      imageUrl,
      testRequirement,
      startingPrice,
      reportsDuration
    };
    onSave(newTest);
    toggleOff();
  };

  return (
    <MDBModal open={isOpen} setOpen={toggleOff} tabIndex='-1'>
      <MDBModalDialog>
        <MDBModalContent>
          <MDBModalHeader>
            <MDBModalTitle>Add Test</MDBModalTitle>
            <MDBBtn className='btn-close' color='none' onClick={toggleOff}></MDBBtn>
          </MDBModalHeader>
          <MDBModalBody>
          <form>
                  <div className="form-group">
                    <label htmlFor="test-type">Type:</label>
                    <input type="text" className="form-control" id="test-type" onChange={(e) => setTestType(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="test-name">Name:</label>
                    <input type="text" className="form-control" id="test-name" onChange={(e) => setTestName(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="test-id">ID:</label>
                    <input type="text" className="form-control" id="test-id" onChange={(e) => setTestId(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="test-description">Description:</label>
                    <textarea className="form-control" id="test-description" rows="3" onChange={(e) => setTestDescription(e.target.value)}></textarea>
                  </div>
                  <div className="form-group">
                    <label htmlFor="test-alias">Test Alias:</label>
                    <input type="text" className="form-control" id="test-alias" onChange={(e) => setTestAlias(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="test-instructions">Instructions:</label>
                    <textarea className="form-control" id="test-instructions" rows="3" onChange={(e) => setTestInstructions(e.target.value)}></textarea>
                  </div>
                  <div className="form-group">
                    <label htmlFor="short-description">Short Description:</label>
                    <input type="text" className="form-control" id="short-description" onChange={(e) => setShortDescription(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="image-url">Image URL:</label>
                    <input type="text" className="form-control" id="image-url" onChange={(e) => setImageUrl(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="test-requirement">Test Requirement:</label>
                    <input type="text" className="form-control" id="test-requirement" onChange={(e) => setTestRequirement(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="starting-price">Starting Price:</label>
                    <input type="text" className="form-control" id="starting-price" onChange={(e) => setStartingPrice(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="reports-duration">Reports Duration:</label>
                    <input type="text" className="form-control" id="reports-duration" onChange={(e) => setReportsDuration(e.target.value)} />
                  </div>
                </form>
          </MDBModalBody>
          <MDBModalFooter>
            <MDBBtn color='#75DBD0' onClick={toggleOff}>Close</MDBBtn>
            <MDBBtn type="submit" color='#75DBD0'>Save Changes</MDBBtn>
          </MDBModalFooter>
        </MDBModalContent>
      </MDBModalDialog>
    </MDBModal>
  );
};

export default CustomTestForm;





/*
   <form>
                  <div className="form-group">
                    <label htmlFor="test-type">Type:</label>
                    <input type="text" className="form-control" id="test-type" onChange={(e) => setTestType(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="test-name">Name:</label>
                    <input type="text" className="form-control" id="test-name" onChange={(e) => setTestName(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="test-id">ID:</label>
                    <input type="text" className="form-control" id="test-id" onChange={(e) => setTestId(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="test-description">Description:</label>
                    <textarea className="form-control" id="test-description" rows="3" onChange={(e) => setTestDescription(e.target.value)}></textarea>
                  </div>
                  <div className="form-group">
                    <label htmlFor="test-alias">Test Alias:</label>
                    <input type="text" className="form-control" id="test-alias" onChange={(e) => setTestAlias(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="test-instructions">Instructions:</label>
                    <textarea className="form-control" id="test-instructions" rows="3" onChange={(e) => setTestInstructions(e.target.value)}></textarea>
                  </div>
                  <div className="form-group">
                    <label htmlFor="short-description">Short Description:</label>
                    <input type="text" className="form-control" id="short-description" onChange={(e) => setShortDescription(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="image-url">Image URL:</label>
                    <input type="text" className="form-control" id="image-url" onChange={(e) => setImageUrl(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="test-requirement">Test Requirement:</label>
                    <input type="text" className="form-control" id="test-requirement" onChange={(e) => setTestRequirement(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="starting-price">Starting Price:</label>
                    <input type="text" className="form-control" id="starting-price" onChange={(e) => setStartingPrice(e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label htmlFor="reports-duration">Reports Duration:</label>
                    <input type="text" className="form-control" id="reports-duration" onChange={(e) => setReportsDuration(e.target.value)} />
                  </div>
                </form>
*/ 