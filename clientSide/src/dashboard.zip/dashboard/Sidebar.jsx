import React, { useState } from 'react';
import {
    FaTh,
    FaBars,
    FaUserAlt,
    FaRegChartBar,
    FaCommentAlt,
}from "react-icons/fa";
import './sidebar.css';

import { NavLink } from 'react-router-dom';


const Sidebar = ({children}) => {
    const[isOpen ,setIsOpen] = useState(false);
    const toggle = () => setIsOpen (!isOpen);
    const menuItem=[
        {
            path:"/dashboard",
            name:"Dashboard",
            icon:<FaTh/>
        },
        {
            path:"/offeredtest",
            name:"Offered Test",
            icon:<FaUserAlt/>
        },
        {
            path:"/orders",
            name:"Orders",
            icon:<FaRegChartBar/>
        },
        {
            path:"/pages",
            name:"Pages",
            icon:<FaCommentAlt/>
        },
    ]
    return (
        <div className="containers">
           <div style={{width: isOpen ? "400px" : "200px"}} className="sidebars">
               <div className="top_sections">
                   <h1 style={{display: isOpen ? "block" : "none"}} className="logos">Logo</h1>
                   <div style={{marginLeft: isOpen ? "150px" : "1px"}} className="bars">
                       <FaBars className='barss' onClick={toggle}/>
                   </div>
               </div>
               {
                   menuItem.map((item, index)=>(
                       <NavLink to={item.path} key={index} className="links" activeclassName="active">
                           <div className="icons">{item.icon}</div>
                           <div style={{display: isOpen ? "block" : "none"}} className="link_texts">{item.name}</div>
                       </NavLink>
                   ))
               }
           </div>
           <main className='mains'>{children}</main>
        </div>
    );
};

export default Sidebar;